import java.util.Scanner;

public class AndOperator {
    public static void main(String[] args) {
        Scanner object=new Scanner(System.in);

        int number1= object.nextInt();
        int number2= object.nextInt();

        // bitwise & (and) operator

        int operation = number1 & number2;
        System.out.println(operation);















    }
}
