public class Reversebits {
    public static void main(String[] args) {

        // write a java program to reverse the bits of a given number





















    }
}
