public class Exercise_3 {
    public static void main(String[] args) {




        // write a java program to find the highest power of 2 that is less than or equal to a given number using
        // bitwise operator

       int number=78;
       int result;

       number-=1;





    }
}
